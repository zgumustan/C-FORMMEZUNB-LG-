﻿namespace GraduationSystem
{
    partial class FrmOgrenciPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGüncelle = new System.Windows.Forms.Button();
            this.lblAdres = new System.Windows.Forms.Label();
            this.txtMezuniyetTarihi = new System.Windows.Forms.TextBox();
            this.txtEvTel = new System.Windows.Forms.TextBox();
            this.txtCepTel = new System.Windows.Forms.TextBox();
            this.txtMail = new System.Windows.Forms.TextBox();
            this.lblCepTel = new System.Windows.Forms.Label();
            this.lblMezuniyetTarihi = new System.Windows.Forms.Label();
            this.lblMail = new System.Windows.Forms.Label();
            this.txtAdres = new System.Windows.Forms.TextBox();
            this.txtSehir = new System.Windows.Forms.TextBox();
            this.txtUlke = new System.Windows.Forms.TextBox();
            this.lblSehir = new System.Windows.Forms.Label();
            this.lblUlke = new System.Windows.Forms.Label();
            this.lblEvTel = new System.Windows.Forms.Label();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.lblSifre = new System.Windows.Forms.Label();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.txtNumara = new System.Windows.Forms.TextBox();
            this.lblNumara = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGüncelle
            // 
            this.btnGüncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGüncelle.Location = new System.Drawing.Point(119, 432);
            this.btnGüncelle.Name = "btnGüncelle";
            this.btnGüncelle.Size = new System.Drawing.Size(188, 32);
            this.btnGüncelle.TabIndex = 36;
            this.btnGüncelle.Text = "Güncelle";
            this.btnGüncelle.UseVisualStyleBackColor = true;
            this.btnGüncelle.Click += new System.EventHandler(this.btnGüncelle_Click);
            // 
            // lblAdres
            // 
            this.lblAdres.AutoSize = true;
            this.lblAdres.Location = new System.Drawing.Point(29, 390);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(37, 13);
            this.lblAdres.TabIndex = 35;
            this.lblAdres.Text = "Adres:";
            // 
            // txtMezuniyetTarihi
            // 
            this.txtMezuniyetTarihi.Location = new System.Drawing.Point(119, 293);
            this.txtMezuniyetTarihi.Name = "txtMezuniyetTarihi";
            this.txtMezuniyetTarihi.Size = new System.Drawing.Size(189, 20);
            this.txtMezuniyetTarihi.TabIndex = 34;
            // 
            // txtEvTel
            // 
            this.txtEvTel.Location = new System.Drawing.Point(119, 262);
            this.txtEvTel.Name = "txtEvTel";
            this.txtEvTel.Size = new System.Drawing.Size(189, 20);
            this.txtEvTel.TabIndex = 33;
            // 
            // txtCepTel
            // 
            this.txtCepTel.Location = new System.Drawing.Point(119, 231);
            this.txtCepTel.Name = "txtCepTel";
            this.txtCepTel.Size = new System.Drawing.Size(189, 20);
            this.txtCepTel.TabIndex = 32;
            // 
            // txtMail
            // 
            this.txtMail.Location = new System.Drawing.Point(119, 197);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(189, 20);
            this.txtMail.TabIndex = 31;
            // 
            // lblCepTel
            // 
            this.lblCepTel.AutoSize = true;
            this.lblCepTel.Location = new System.Drawing.Point(24, 231);
            this.lblCepTel.Name = "lblCepTel";
            this.lblCepTel.Size = new System.Drawing.Size(47, 13);
            this.lblCepTel.TabIndex = 30;
            this.lblCepTel.Text = "Cep Tel:";
            // 
            // lblMezuniyetTarihi
            // 
            this.lblMezuniyetTarihi.AutoSize = true;
            this.lblMezuniyetTarihi.Location = new System.Drawing.Point(24, 298);
            this.lblMezuniyetTarihi.Name = "lblMezuniyetTarihi";
            this.lblMezuniyetTarihi.Size = new System.Drawing.Size(71, 13);
            this.lblMezuniyetTarihi.TabIndex = 29;
            this.lblMezuniyetTarihi.Text = "Mezun Tarihi:";
            // 
            // lblMail
            // 
            this.lblMail.AutoSize = true;
            this.lblMail.Location = new System.Drawing.Point(24, 197);
            this.lblMail.Name = "lblMail";
            this.lblMail.Size = new System.Drawing.Size(29, 13);
            this.lblMail.TabIndex = 28;
            this.lblMail.Text = "Mail:";
            // 
            // txtAdres
            // 
            this.txtAdres.Location = new System.Drawing.Point(119, 390);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(189, 20);
            this.txtAdres.TabIndex = 27;
            // 
            // txtSehir
            // 
            this.txtSehir.Location = new System.Drawing.Point(119, 356);
            this.txtSehir.Name = "txtSehir";
            this.txtSehir.Size = new System.Drawing.Size(189, 20);
            this.txtSehir.TabIndex = 26;
            // 
            // txtUlke
            // 
            this.txtUlke.Location = new System.Drawing.Point(119, 323);
            this.txtUlke.Name = "txtUlke";
            this.txtUlke.Size = new System.Drawing.Size(189, 20);
            this.txtUlke.TabIndex = 25;
            // 
            // lblSehir
            // 
            this.lblSehir.AutoSize = true;
            this.lblSehir.Location = new System.Drawing.Point(24, 359);
            this.lblSehir.Name = "lblSehir";
            this.lblSehir.Size = new System.Drawing.Size(34, 13);
            this.lblSehir.TabIndex = 24;
            this.lblSehir.Text = "Şehir:";
            // 
            // lblUlke
            // 
            this.lblUlke.AutoSize = true;
            this.lblUlke.Location = new System.Drawing.Point(24, 326);
            this.lblUlke.Name = "lblUlke";
            this.lblUlke.Size = new System.Drawing.Size(32, 13);
            this.lblUlke.TabIndex = 23;
            this.lblUlke.Text = "Ülke:";
            // 
            // lblEvTel
            // 
            this.lblEvTel.AutoSize = true;
            this.lblEvTel.Location = new System.Drawing.Point(24, 267);
            this.lblEvTel.Name = "lblEvTel";
            this.lblEvTel.Size = new System.Drawing.Size(41, 13);
            this.lblEvTel.TabIndex = 22;
            this.lblEvTel.Text = "Ev Tel:";
            // 
            // txtSifre
            // 
            this.txtSifre.Location = new System.Drawing.Point(119, 156);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(189, 20);
            this.txtSifre.TabIndex = 21;
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.Location = new System.Drawing.Point(24, 156);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(31, 13);
            this.lblSifre.TabIndex = 20;
            this.lblSifre.Text = "Şifre:";
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(119, 120);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(189, 20);
            this.txtSoyad.TabIndex = 19;
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(119, 84);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(189, 20);
            this.txtAd.TabIndex = 18;
            // 
            // lblSoyad
            // 
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.Location = new System.Drawing.Point(24, 123);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(40, 13);
            this.lblSoyad.TabIndex = 17;
            this.lblSoyad.Text = "Soyad:";
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.Location = new System.Drawing.Point(24, 89);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(23, 13);
            this.lblAd.TabIndex = 16;
            this.lblAd.Text = "Ad:";
            // 
            // txtNumara
            // 
            this.txtNumara.Location = new System.Drawing.Point(119, 44);
            this.txtNumara.Name = "txtNumara";
            this.txtNumara.Size = new System.Drawing.Size(189, 20);
            this.txtNumara.TabIndex = 15;
            // 
            // lblNumara
            // 
            this.lblNumara.AutoSize = true;
            this.lblNumara.Location = new System.Drawing.Point(24, 49);
            this.lblNumara.Name = "lblNumara";
            this.lblNumara.Size = new System.Drawing.Size(47, 13);
            this.lblNumara.TabIndex = 14;
            this.lblNumara.Text = "Numara:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(39, 15);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(224, 16);
            this.label13.TabIndex = 13;
            this.label13.Text = "Öğrenci Bilgi Düzenleme Formu";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnGüncelle);
            this.groupBox1.Controls.Add(this.lblAdres);
            this.groupBox1.Controls.Add(this.txtMezuniyetTarihi);
            this.groupBox1.Controls.Add(this.txtEvTel);
            this.groupBox1.Controls.Add(this.txtCepTel);
            this.groupBox1.Controls.Add(this.txtMail);
            this.groupBox1.Controls.Add(this.lblCepTel);
            this.groupBox1.Controls.Add(this.lblMezuniyetTarihi);
            this.groupBox1.Controls.Add(this.lblMail);
            this.groupBox1.Controls.Add(this.txtAdres);
            this.groupBox1.Controls.Add(this.txtSehir);
            this.groupBox1.Controls.Add(this.txtUlke);
            this.groupBox1.Controls.Add(this.lblSehir);
            this.groupBox1.Controls.Add(this.lblUlke);
            this.groupBox1.Controls.Add(this.lblEvTel);
            this.groupBox1.Controls.Add(this.txtSifre);
            this.groupBox1.Controls.Add(this.lblSifre);
            this.groupBox1.Controls.Add(this.txtSoyad);
            this.groupBox1.Controls.Add(this.txtAd);
            this.groupBox1.Controls.Add(this.lblSoyad);
            this.groupBox1.Controls.Add(this.lblAd);
            this.groupBox1.Controls.Add(this.txtNumara);
            this.groupBox1.Controls.Add(this.lblNumara);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Location = new System.Drawing.Point(668, -4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(417, 521);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(74, 33);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(564, 274);
            this.dataGridView1.TabIndex = 14;
            // 
            // FrmOgrenciPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(1159, 513);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FrmOgrenciPanel";
            this.Text = "FrmOgrenciPanel";
            this.Load += new System.EventHandler(this.FrmOgrenciPanel_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGüncelle;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.TextBox txtMezuniyetTarihi;
        private System.Windows.Forms.TextBox txtEvTel;
        private System.Windows.Forms.TextBox txtCepTel;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.Label lblCepTel;
        private System.Windows.Forms.Label lblMezuniyetTarihi;
        private System.Windows.Forms.Label lblMail;
        private System.Windows.Forms.TextBox txtAdres;
        private System.Windows.Forms.TextBox txtSehir;
        private System.Windows.Forms.TextBox txtUlke;
        private System.Windows.Forms.Label lblSehir;
        private System.Windows.Forms.Label lblUlke;
        private System.Windows.Forms.Label lblEvTel;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label lblSoyad;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.TextBox txtNumara;
        private System.Windows.Forms.Label lblNumara;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}