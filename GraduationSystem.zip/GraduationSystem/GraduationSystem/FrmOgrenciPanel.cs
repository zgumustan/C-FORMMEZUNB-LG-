﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace GraduationSystem
{
    public partial class FrmOgrenciPanel : Form
    {
        MySqlConnection baglanti = new MySqlConnection("Server=localhost;Database=mezun_bilgi_sistemi;user=root;Pwd='';");

        public string numara;

        public FrmOgrenciPanel()
        {
            InitializeComponent();
        }

        private void FrmOgrenciPanel_Load(object sender, EventArgs e)
        {
            txtNumara.Text = numara;
            GetStudentInfo(numara);
        }

        private void GetStudentInfo(string studentNumber)
        {
            if (string.IsNullOrEmpty(studentNumber))
            {
                MessageBox.Show("Lütfen bir numara girin.");
                return;
            }

            try
            {
                baglanti.Open();
                string query = "SELECT * FROM tblkayitekle WHERE ogrenci_numara = @ogrenciNumara";

                using (MySqlCommand cmd = new MySqlCommand(query, baglanti))
                {
                    cmd.Parameters.AddWithValue("@ogrenciNumara", studentNumber);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtAd.Text = reader["ad"].ToString();
                            txtSoyad.Text = reader["soyad"].ToString();
                            txtSifre.Text = reader["sifre"].ToString();
                            txtMail.Text = reader["mail"].ToString();
                            txtCepTel.Text = reader["cep_tel"].ToString();
                            txtEvTel.Text = reader["ev_tel"].ToString();
                            txtMezuniyetTarihi.Text = reader["mezuniyet_tarihi"].ToString();
                            txtUlke.Text = reader["ulke"].ToString();
                            txtSehir.Text = reader["sehir"].ToString();
                            txtAdres.Text = reader["adres"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Öğrenci bulunamadı.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }
        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo();
        }

        private void UpdateStudentInfo()
        {
            try
            {
                baglanti.Open();
                string query = @"UPDATE tblkayitekle SET
                            ad = @ad,
                            soyad = @soyad,
                            sifre = @sifre,
                            mail = @mail,
                            cep_tel = @cep_tel,
                            ev_tel = @ev_tel,
                            mezuniyet_tarihi = @mezuniyet_tarihi,
                            ulke = @ulke,
                            sehir = @sehir,
                            adres = @adres
                            WHERE ogrenci_numara = @ogrenciNumara";

                using (MySqlCommand cmd = new MySqlCommand(query, baglanti))
                {
                    cmd.Parameters.AddWithValue("@ad", txtAd.Text);
                    cmd.Parameters.AddWithValue("@soyad", txtSoyad.Text);
                    cmd.Parameters.AddWithValue("@sifre", txtSifre.Text);
                    cmd.Parameters.AddWithValue("@mail", txtMail.Text);
                    cmd.Parameters.AddWithValue("@cep_tel", txtCepTel.Text);
                    cmd.Parameters.AddWithValue("@ev_tel", txtEvTel.Text);
                    cmd.Parameters.AddWithValue("@mezuniyet_tarihi", txtMezuniyetTarihi.Text);
                    cmd.Parameters.AddWithValue("@ulke", txtUlke.Text);
                    cmd.Parameters.AddWithValue("@sehir", txtSehir.Text);
                    cmd.Parameters.AddWithValue("@adres", txtAdres.Text);
                    cmd.Parameters.AddWithValue("@ogrenciNumara", txtNumara.Text);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Öğrenci bilgileri başarıyla güncellendi.");
                    }
                    else
                    {
                        MessageBox.Show("Güncelleme sırasında bir hata oluştu.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }
        }
    }
}
