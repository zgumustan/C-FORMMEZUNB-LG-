﻿namespace GraduationSystem
{
    partial class KayitEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KayitEkle));
            System.Windows.Forms.TabControl tabControl1;
            this.txtArama = new System.Windows.Forms.TextBox();
            this.lblArama = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnKayitGüncelle = new System.Windows.Forms.Button();
            this.btnKayit = new System.Windows.Forms.Button();
            this.btnKapat = new System.Windows.Forms.Button();
            this.btnKayitSil = new System.Windows.Forms.Button();
            this.btnEkle = new System.Windows.Forms.Button();
            this.txtNotlar = new System.Windows.Forms.TextBox();
            this.lblNotlar = new System.Windows.Forms.Label();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtMezuniyetTarihi = new System.Windows.Forms.TextBox();
            this.txtEposta = new System.Windows.Forms.TextBox();
            this.txtCepTelefon = new System.Windows.Forms.TextBox();
            this.txtEvTel = new System.Windows.Forms.TextBox();
            this.txtUlke = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblMezunBilgiSistemi = new System.Windows.Forms.Label();
            this.txtŞehir = new System.Windows.Forms.TextBox();
            this.txtEvAdres = new System.Windows.Forms.TextBox();
            this.txtÖğrenciNo = new System.Windows.Forms.TextBox();
            this.lblEvAdres = new System.Windows.Forms.Label();
            this.lblŞehir = new System.Windows.Forms.Label();
            this.lblUlke = new System.Windows.Forms.Label();
            this.lblEvTel = new System.Windows.Forms.Label();
            this.lblCepTelefon = new System.Windows.Forms.Label();
            this.lblEposta = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMezuniyetTarihi = new System.Windows.Forms.Label();
            this.lblSoyAd = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.lblÖğrenciNo = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            tabControl1 = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtArama
            // 
            this.txtArama.Location = new System.Drawing.Point(739, 221);
            this.txtArama.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtArama.Name = "txtArama";
            this.txtArama.Size = new System.Drawing.Size(239, 20);
            this.txtArama.TabIndex = 30;
            this.txtArama.TextChanged += new System.EventHandler(this.txtArama_TextChanged);
            // 
            // lblArama
            // 
            this.lblArama.AutoSize = true;
            this.lblArama.Location = new System.Drawing.Point(672, 221);
            this.lblArama.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblArama.Name = "lblArama";
            this.lblArama.Size = new System.Drawing.Size(40, 13);
            this.lblArama.TabIndex = 29;
            this.lblArama.Text = "Arama:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Enabled = false;
            this.dataGridView1.Location = new System.Drawing.Point(448, 273);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(945, 142);
            this.dataGridView1.TabIndex = 28;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // btnKayitGüncelle
            // 
            this.btnKayitGüncelle.Location = new System.Drawing.Point(1152, 120);
            this.btnKayitGüncelle.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnKayitGüncelle.Name = "btnKayitGüncelle";
            this.btnKayitGüncelle.Size = new System.Drawing.Size(136, 23);
            this.btnKayitGüncelle.TabIndex = 27;
            this.btnKayitGüncelle.Text = "Kayıt Güncelle";
            this.btnKayitGüncelle.UseVisualStyleBackColor = true;
            this.btnKayitGüncelle.Click += new System.EventHandler(this.btnKayitGüncelle_Click);
            // 
            // btnKayit
            // 
            this.btnKayit.Location = new System.Drawing.Point(1152, 25);
            this.btnKayit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnKayit.Name = "btnKayit";
            this.btnKayit.Size = new System.Drawing.Size(136, 23);
            this.btnKayit.TabIndex = 26;
            this.btnKayit.Text = "Yeni Kayıt";
            this.btnKayit.UseVisualStyleBackColor = true;
            this.btnKayit.Click += new System.EventHandler(this.btnKayit_Click);
            // 
            // btnKapat
            // 
            this.btnKapat.Location = new System.Drawing.Point(1152, 158);
            this.btnKapat.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnKapat.Name = "btnKapat";
            this.btnKapat.Size = new System.Drawing.Size(136, 23);
            this.btnKapat.TabIndex = 25;
            this.btnKapat.Text = "Kapat";
            this.btnKapat.UseVisualStyleBackColor = true;
            this.btnKapat.Click += new System.EventHandler(this.btnKapat_Click);
            // 
            // btnKayitSil
            // 
            this.btnKayitSil.Location = new System.Drawing.Point(1152, 88);
            this.btnKayitSil.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnKayitSil.Name = "btnKayitSil";
            this.btnKayitSil.Size = new System.Drawing.Size(136, 23);
            this.btnKayitSil.TabIndex = 24;
            this.btnKayitSil.Text = "Kayıt Sil";
            this.btnKayitSil.UseVisualStyleBackColor = true;
            this.btnKayitSil.Click += new System.EventHandler(this.btnKayitSil_Click);
            // 
            // btnEkle
            // 
            this.btnEkle.Location = new System.Drawing.Point(1152, 56);
            this.btnEkle.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(136, 23);
            this.btnEkle.TabIndex = 23;
            this.btnEkle.Text = "Kayıt Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // txtNotlar
            // 
            this.txtNotlar.Location = new System.Drawing.Point(739, 146);
            this.txtNotlar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNotlar.Multiline = true;
            this.txtNotlar.Name = "txtNotlar";
            this.txtNotlar.Size = new System.Drawing.Size(239, 42);
            this.txtNotlar.TabIndex = 22;
            // 
            // lblNotlar
            // 
            this.lblNotlar.AutoSize = true;
            this.lblNotlar.Location = new System.Drawing.Point(658, 168);
            this.lblNotlar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNotlar.Name = "lblNotlar";
            this.lblNotlar.Size = new System.Drawing.Size(38, 13);
            this.lblNotlar.TabIndex = 21;
            this.lblNotlar.Text = "Notlar:";
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(192, 120);
            this.txtSoyad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(239, 20);
            this.txtSoyad.TabIndex = 19;
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(192, 72);
            this.txtAd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(239, 20);
            this.txtAd.TabIndex = 20;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(0, 136);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(1380, 39);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // txtMezuniyetTarihi
            // 
            this.txtMezuniyetTarihi.Location = new System.Drawing.Point(192, 168);
            this.txtMezuniyetTarihi.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMezuniyetTarihi.Name = "txtMezuniyetTarihi";
            this.txtMezuniyetTarihi.Size = new System.Drawing.Size(239, 20);
            this.txtMezuniyetTarihi.TabIndex = 18;
            // 
            // txtEposta
            // 
            this.txtEposta.Location = new System.Drawing.Point(192, 221);
            this.txtEposta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtEposta.Name = "txtEposta";
            this.txtEposta.Size = new System.Drawing.Size(239, 20);
            this.txtEposta.TabIndex = 17;
            // 
            // txtCepTelefon
            // 
            this.txtCepTelefon.Location = new System.Drawing.Point(192, 269);
            this.txtCepTelefon.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCepTelefon.Name = "txtCepTelefon";
            this.txtCepTelefon.Size = new System.Drawing.Size(239, 20);
            this.txtCepTelefon.TabIndex = 16;
            // 
            // txtEvTel
            // 
            this.txtEvTel.Location = new System.Drawing.Point(192, 318);
            this.txtEvTel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtEvTel.Name = "txtEvTel";
            this.txtEvTel.Size = new System.Drawing.Size(239, 20);
            this.txtEvTel.TabIndex = 15;
            // 
            // txtUlke
            // 
            this.txtUlke.Location = new System.Drawing.Point(192, 367);
            this.txtUlke.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtUlke.Name = "txtUlke";
            this.txtUlke.Size = new System.Drawing.Size(239, 20);
            this.txtUlke.TabIndex = 14;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Firebrick;
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.lblMezunBilgiSistemi);
            this.groupBox1.Location = new System.Drawing.Point(1, 1);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(1387, 175);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(148, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // lblMezunBilgiSistemi
            // 
            this.lblMezunBilgiSistemi.AutoSize = true;
            this.lblMezunBilgiSistemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMezunBilgiSistemi.Location = new System.Drawing.Point(441, 31);
            this.lblMezunBilgiSistemi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMezunBilgiSistemi.Name = "lblMezunBilgiSistemi";
            this.lblMezunBilgiSistemi.Size = new System.Drawing.Size(459, 55);
            this.lblMezunBilgiSistemi.TabIndex = 2;
            this.lblMezunBilgiSistemi.Text = "Mezun Bilgi Sistemi";
            // 
            // txtŞehir
            // 
            this.txtŞehir.Location = new System.Drawing.Point(739, 30);
            this.txtŞehir.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtŞehir.Name = "txtŞehir";
            this.txtŞehir.Size = new System.Drawing.Size(239, 20);
            this.txtŞehir.TabIndex = 13;
            // 
            // txtEvAdres
            // 
            this.txtEvAdres.Location = new System.Drawing.Point(739, 56);
            this.txtEvAdres.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtEvAdres.Multiline = true;
            this.txtEvAdres.Name = "txtEvAdres";
            this.txtEvAdres.Size = new System.Drawing.Size(239, 77);
            this.txtEvAdres.TabIndex = 12;
            // 
            // txtÖğrenciNo
            // 
            this.txtÖğrenciNo.Location = new System.Drawing.Point(192, 30);
            this.txtÖğrenciNo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtÖğrenciNo.Name = "txtÖğrenciNo";
            this.txtÖğrenciNo.Size = new System.Drawing.Size(239, 20);
            this.txtÖğrenciNo.TabIndex = 10;
            // 
            // lblEvAdres
            // 
            this.lblEvAdres.AutoSize = true;
            this.lblEvAdres.Location = new System.Drawing.Point(658, 88);
            this.lblEvAdres.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEvAdres.Name = "lblEvAdres";
            this.lblEvAdres.Size = new System.Drawing.Size(53, 13);
            this.lblEvAdres.TabIndex = 9;
            this.lblEvAdres.Text = "Ev Adres:";
            // 
            // lblŞehir
            // 
            this.lblŞehir.AutoSize = true;
            this.lblŞehir.Location = new System.Drawing.Point(658, 30);
            this.lblŞehir.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblŞehir.Name = "lblŞehir";
            this.lblŞehir.Size = new System.Drawing.Size(50, 13);
            this.lblŞehir.TabIndex = 8;
            this.lblŞehir.Text = "Ev Şehir:";
            // 
            // lblUlke
            // 
            this.lblUlke.AutoSize = true;
            this.lblUlke.Location = new System.Drawing.Point(48, 373);
            this.lblUlke.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUlke.Name = "lblUlke";
            this.lblUlke.Size = new System.Drawing.Size(48, 13);
            this.lblUlke.TabIndex = 7;
            this.lblUlke.Text = "Ev Ülke:";
            // 
            // lblEvTel
            // 
            this.lblEvTel.AutoSize = true;
            this.lblEvTel.Location = new System.Drawing.Point(48, 324);
            this.lblEvTel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEvTel.Name = "lblEvTel";
            this.lblEvTel.Size = new System.Drawing.Size(62, 13);
            this.lblEvTel.TabIndex = 6;
            this.lblEvTel.Text = "Ev Telefon:";
            // 
            // lblCepTelefon
            // 
            this.lblCepTelefon.AutoSize = true;
            this.lblCepTelefon.Location = new System.Drawing.Point(48, 272);
            this.lblCepTelefon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCepTelefon.Name = "lblCepTelefon";
            this.lblCepTelefon.Size = new System.Drawing.Size(68, 13);
            this.lblCepTelefon.TabIndex = 5;
            this.lblCepTelefon.Text = "Cep Telefon:";
            // 
            // lblEposta
            // 
            this.lblEposta.AutoSize = true;
            this.lblEposta.Location = new System.Drawing.Point(48, 227);
            this.lblEposta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEposta.Name = "lblEposta";
            this.lblEposta.Size = new System.Drawing.Size(46, 13);
            this.lblEposta.TabIndex = 4;
            this.lblEposta.Text = "E-posta:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(425, 235);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 12;
            // 
            // lblMezuniyetTarihi
            // 
            this.lblMezuniyetTarihi.AutoSize = true;
            this.lblMezuniyetTarihi.Location = new System.Drawing.Point(48, 174);
            this.lblMezuniyetTarihi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMezuniyetTarihi.Name = "lblMezuniyetTarihi";
            this.lblMezuniyetTarihi.Size = new System.Drawing.Size(87, 13);
            this.lblMezuniyetTarihi.TabIndex = 3;
            this.lblMezuniyetTarihi.Text = "Mezuniyet Tarihi:";
            // 
            // lblSoyAd
            // 
            this.lblSoyAd.AutoSize = true;
            this.lblSoyAd.Location = new System.Drawing.Point(48, 120);
            this.lblSoyAd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSoyAd.Name = "lblSoyAd";
            this.lblSoyAd.Size = new System.Drawing.Size(40, 13);
            this.lblSoyAd.TabIndex = 2;
            this.lblSoyAd.Text = "Soyad:";
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.Location = new System.Drawing.Point(48, 78);
            this.lblAd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(23, 13);
            this.lblAd.TabIndex = 1;
            this.lblAd.Text = "Ad:";
            // 
            // lblÖğrenciNo
            // 
            this.lblÖğrenciNo.AutoSize = true;
            this.lblÖğrenciNo.Location = new System.Drawing.Point(48, 30);
            this.lblÖğrenciNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblÖğrenciNo.Name = "lblÖğrenciNo";
            this.lblÖğrenciNo.Size = new System.Drawing.Size(64, 13);
            this.lblÖğrenciNo.TabIndex = 0;
            this.lblÖğrenciNo.Text = "Öğrenci No:";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(this.tabPage2);
            tabControl1.Location = new System.Drawing.Point(1, 176);
            tabControl1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new System.Drawing.Size(1422, 450);
            tabControl1.TabIndex = 13;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtArama);
            this.tabPage2.Controls.Add(this.lblArama);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.btnKayitGüncelle);
            this.tabPage2.Controls.Add(this.btnKayit);
            this.tabPage2.Controls.Add(this.btnKapat);
            this.tabPage2.Controls.Add(this.btnKayitSil);
            this.tabPage2.Controls.Add(this.btnEkle);
            this.tabPage2.Controls.Add(this.txtNotlar);
            this.tabPage2.Controls.Add(this.lblNotlar);
            this.tabPage2.Controls.Add(this.txtAd);
            this.tabPage2.Controls.Add(this.txtSoyad);
            this.tabPage2.Controls.Add(this.txtMezuniyetTarihi);
            this.tabPage2.Controls.Add(this.txtEposta);
            this.tabPage2.Controls.Add(this.txtCepTelefon);
            this.tabPage2.Controls.Add(this.txtEvTel);
            this.tabPage2.Controls.Add(this.txtUlke);
            this.tabPage2.Controls.Add(this.txtŞehir);
            this.tabPage2.Controls.Add(this.txtEvAdres);
            this.tabPage2.Controls.Add(this.txtÖğrenciNo);
            this.tabPage2.Controls.Add(this.lblEvAdres);
            this.tabPage2.Controls.Add(this.lblŞehir);
            this.tabPage2.Controls.Add(this.lblUlke);
            this.tabPage2.Controls.Add(this.lblEvTel);
            this.tabPage2.Controls.Add(this.lblCepTelefon);
            this.tabPage2.Controls.Add(this.lblEposta);
            this.tabPage2.Controls.Add(this.lblMezuniyetTarihi);
            this.tabPage2.Controls.Add(this.lblSoyAd);
            this.tabPage2.Controls.Add(this.lblAd);
            this.tabPage2.Controls.Add(this.lblÖğrenciNo);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage2.Size = new System.Drawing.Size(1414, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Yeni Kayıt";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click_1);
            // 
            // KayitEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1508, 634);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(tabControl1);
            this.Name = "KayitEkle";
            this.Text = "KayitEkle";
            this.Load += new System.EventHandler(this.KayitEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtArama;
        private System.Windows.Forms.Label lblArama;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnKayitGüncelle;
        private System.Windows.Forms.Button btnKayit;
        private System.Windows.Forms.Button btnKapat;
        private System.Windows.Forms.Button btnKayitSil;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.TextBox txtNotlar;
        private System.Windows.Forms.Label lblNotlar;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMezuniyetTarihi;
        private System.Windows.Forms.TextBox txtEposta;
        private System.Windows.Forms.TextBox txtCepTelefon;
        private System.Windows.Forms.TextBox txtEvTel;
        private System.Windows.Forms.TextBox txtUlke;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblMezunBilgiSistemi;
        private System.Windows.Forms.TextBox txtŞehir;
        private System.Windows.Forms.TextBox txtEvAdres;
        private System.Windows.Forms.TextBox txtÖğrenciNo;
        private System.Windows.Forms.Label lblEvAdres;
        private System.Windows.Forms.Label lblŞehir;
        private System.Windows.Forms.Label lblUlke;
        private System.Windows.Forms.Label lblEvTel;
        private System.Windows.Forms.Label lblCepTelefon;
        private System.Windows.Forms.Label lblEposta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMezuniyetTarihi;
        private System.Windows.Forms.Label lblSoyAd;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.Label lblÖğrenciNo;
        private System.Windows.Forms.TabPage tabPage2;
    }
}