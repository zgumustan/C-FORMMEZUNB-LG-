﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace GraduationSystem
{
    public partial class KayitEkle : Form
    {
        MySqlConnection baglanti = new MySqlConnection("Server = localhost; Database=mezun_bilgi_sistemi;user=root;Pwd=");

        public KayitEkle()
        {
            InitializeComponent();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click_1(object sender, EventArgs e)
        {

        }

        private void btnKayit_Click(object sender, EventArgs e)
        {
            txtÖğrenciNo.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtMezuniyetTarihi.Text = "";
            txtEposta.Text = "";
            txtCepTelefon.Text = "";
            txtEvTel.Text = "";
            txtUlke.Text = "";
            txtŞehir.Text = "";
            txtEvAdres.Text = "";
            txtNotlar.Text = "";
            txtÖğrenciNo.Focus();

        }

        private void KayitEkle_Load(object sender, EventArgs e)
        {
            Kayıt();
        }

        private void Kayıt()
        {
            baglanti.Open();
            MySqlDataAdapter adaptor = new MySqlDataAdapter(
               "SELECT * FROM tblkayitekle ORDER BY ogrenci_no", baglanti);
            DataTable dt = new DataTable();

            dt.Clear();
            adaptor.Fill(dt); // Tabloyu doldur doldur
            dataGridView1.DataSource = dt; //Datagrid doldur
                                           //Datagrid doldur
            adaptor.Dispose(); //Adaptor ü kapat
            baglanti.Close(); // Bağlantıyı kapat 

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtÖğrenciNo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtSoyad.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtMezuniyetTarihi.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtEposta.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtCepTelefon.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtEvTel.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtUlke.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtŞehir.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtEvAdres.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            txtNotlar.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            int satir;
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand();

            komut.CommandText = "INSERT INTO tblkayitekle (ogrenci_no, ad, soyad, mezuniyet_tarihi, eposta, cep_telefonu, ev_telefonu, ulke, sehir, notlar) " +
                                  "VALUES (@pogrenci_no, @pad, @psoyad, @pmezuniyet_tarihi, @peposta, @pcep_telefonu, @pev_telefonu, @pulke, @psehir, @pnotlar)";
            komut.Parameters.AddWithValue("@pogrenci_no", txtÖğrenciNo.Text);
            komut.Parameters.AddWithValue("@pad", txtAd.Text);
            komut.Parameters.AddWithValue("@psoyad", txtSoyad.Text);
            komut.Parameters.AddWithValue("@pmezuniyet_tarihi", txtMezuniyetTarihi.Text);
            komut.Parameters.AddWithValue("@peposta", txtEposta.Text);
            komut.Parameters.AddWithValue("@pcep_telefonu", txtCepTelefon.Text);
            komut.Parameters.AddWithValue("@pev_telefonu", txtEvTel.Text);
            komut.Parameters.AddWithValue("@pulke", txtUlke.Text);
            komut.Parameters.AddWithValue("@psehir", txtŞehir.Text);
            komut.Parameters.AddWithValue("@pnotlar", txtEvAdres.Text);
            komut.Parameters.AddWithValue("@pnotlar", txtNotlar.Text);
            komut.Parameters.AddWithValue("@pnotlar", txtEvAdres.Text);

            komut.Connection = baglanti;
            satir = komut.ExecuteNonQuery();
            MessageBox.Show(satir + " satır eklendi");
            komut.Dispose();
            baglanti.Close(); // Bağlantıyı kapat


        }
        private void btnKayitGüncelle_Click(object sender, EventArgs e)
        {
            Int32 satir;
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand();

            komut.CommandText = "INSERT INTO tblkayitekle (ogrenci_no, ad, soyad, mezuniyet_tarihi, eposta, cep_telefonu, ev_telefonu, ulke, sehir, notlar) " +
                                  "VALUES (@pogrenci_no, @pad, @psoyad, @pmezuniyet_tarihi, @peposta, @pcep_telefonu, @pev_telefonu, @pulke, @psehir, @pnotlar)";
            komut.Parameters.AddWithValue("@pogrenci_no", txtÖğrenciNo.Text);
            komut.Parameters.AddWithValue("@pad", txtAd.Text);
            komut.Parameters.AddWithValue("@psoyad", txtSoyad.Text);
            komut.Parameters.AddWithValue("@pmezuniyet_tarihi", txtMezuniyetTarihi.Text);
            komut.Parameters.AddWithValue("@peposta", txtEposta.Text);
            komut.Parameters.AddWithValue("@pcep_telefonu", txtCepTelefon.Text);
            komut.Parameters.AddWithValue("@pev_telefonu", txtEvTel.Text);
            komut.Parameters.AddWithValue("@pulke", txtUlke.Text);
            komut.Parameters.AddWithValue("@psehir", txtŞehir.Text);
            komut.Parameters.AddWithValue("@pnotlar", txtEvAdres.Text);
            komut.Parameters.AddWithValue("@pnotlar", txtNotlar.Text);
            komut.Parameters.AddWithValue("@pnotlar", txtEvAdres.Text);

            komut.Connection = baglanti;
            satir = komut.ExecuteNonQuery();
            MessageBox.Show(satir + " satır değişti");
            komut.Dispose();
            baglanti.Close();
            Kayıt();
        }

        private void btnKayitSil_Click(object sender, EventArgs e)
        {
            DialogResult cevap;
            Int32 satir;
            cevap = MessageBox.Show("Silmek istediğinizden emin misiniz?", "Uyarı!",
                     MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (cevap == DialogResult.Yes)
            {
                baglanti.Open();
                MySqlCommand komut = new MySqlCommand();

                komut.CommandText = "DELETE FROM tblkayitekle WHERE ogrenci_no= @pogrenci_no";

                komut.Parameters.AddWithValue("@pogrenci_no", txtÖğrenciNo.Text);
                komut.Connection = baglanti;
                satir = komut.ExecuteNonQuery();
                MessageBox.Show(satir + " satır silindi");
                komut.Dispose();
                baglanti.Close();

                Kayıt();
            }

        }

        private void btnKapat_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void txtArama_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView1.DataSource;
            bs.Filter = "ogrenci_no LIKE '%" + txtArama.Text + "%'";
            dataGridView1.DataSource = bs;

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}