﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GraduationSystem
{
    public partial class listele : Form
    {
        MySqlConnection baglanti = new MySqlConnection("Server=localhost;Database=mezun_bilgi_sistemi;user=root;Pwd='';");

        public listele()
        {
            InitializeComponent();
        }

        private void listele_Load(object sender, EventArgs e)
        {
            Listele();
        }

        private void Listele()
        {
            try
            {
                baglanti.Open();
                string query = "SELECT * FROM tblkayitekle";
                MySqlCommand cmd = new MySqlCommand(query, baglanti);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }
        }
    }
}
