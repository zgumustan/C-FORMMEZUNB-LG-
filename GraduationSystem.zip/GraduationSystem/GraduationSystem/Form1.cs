﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace GraduationSystem
{
    public partial class Form1 : Form
    {
        MySqlConnection baglanti = new MySqlConnection("Server=localhost;Database=mezun_bilgi_sistemi;user=root;Pwd='';");

        public Form1()
        {
            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("Select * From  tblkayitekle Where ogrenci_no=@p1 and sifre=@p2", baglanti);
            komut.Parameters.AddWithValue("@p1", txtNumara.Text);
            komut.Parameters.AddWithValue("p2", txtSifre.Text);
            MySqlDataReader reader = komut.ExecuteReader();
            if (reader.Read())
            {
                FrmOgrenciPanel frm = new FrmOgrenciPanel();
                frm.numara = txtNumara.Text;
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Numaranız veya şifreniz hatalıdır, lütfen tekar deneyin", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            baglanti.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNumara_TextChanged(object sender, EventArgs e)
        {
            if(txtNumara.Text == "00000" && txtSifre.Text == "000")
            {
                FrmAkademisyenHrta frm = new FrmAkademisyenHrta();
                frm.Show();
                this.Hide();
            }
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            if (txtSifre.Text == "000" && txtNumara.Text == "00000")
            {
                FrmAkademisyenHrta frm = new FrmAkademisyenHrta();
                frm.Show();
                this.Hide();
            }
        }
    }
}
