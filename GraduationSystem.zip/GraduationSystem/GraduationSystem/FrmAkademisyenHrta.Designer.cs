﻿namespace GraduationSystem
{
    partial class FrmAkademisyenHrta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEğitimBilgileri = new System.Windows.Forms.Button();
            this.btnİsBilgileri = new System.Windows.Forms.Button();
            this.btnKayıt = new System.Windows.Forms.Button();
            this.btnListele = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEğitimBilgileri
            // 
            this.btnEğitimBilgileri.Location = new System.Drawing.Point(117, 45);
            this.btnEğitimBilgileri.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnEğitimBilgileri.Name = "btnEğitimBilgileri";
            this.btnEğitimBilgileri.Size = new System.Drawing.Size(193, 93);
            this.btnEğitimBilgileri.TabIndex = 0;
            this.btnEğitimBilgileri.Text = "Mezun Öğrenci Eğitim Bilgileri";
            this.btnEğitimBilgileri.UseVisualStyleBackColor = true;
            // 
            // btnİsBilgileri
            // 
            this.btnİsBilgileri.Location = new System.Drawing.Point(417, 45);
            this.btnİsBilgileri.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnİsBilgileri.Name = "btnİsBilgileri";
            this.btnİsBilgileri.Size = new System.Drawing.Size(170, 93);
            this.btnİsBilgileri.TabIndex = 1;
            this.btnİsBilgileri.Text = "Mezun Öğrenci İş Bilgileri";
            this.btnİsBilgileri.UseVisualStyleBackColor = true;
            // 
            // btnKayıt
            // 
            this.btnKayıt.Location = new System.Drawing.Point(417, 218);
            this.btnKayıt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnKayıt.Name = "btnKayıt";
            this.btnKayıt.Size = new System.Drawing.Size(170, 83);
            this.btnKayıt.TabIndex = 3;
            this.btnKayıt.Text = "Mezun Öğrenci Kayıt";
            this.btnKayıt.UseVisualStyleBackColor = true;
            // 
            // btnListele
            // 
            this.btnListele.Location = new System.Drawing.Point(117, 218);
            this.btnListele.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnListele.Name = "btnListele";
            this.btnListele.Size = new System.Drawing.Size(193, 83);
            this.btnListele.TabIndex = 4;
            this.btnListele.Text = "Öğrenci Listele";
            this.btnListele.UseVisualStyleBackColor = true;
            // 
            // FrmAkademisyenHrta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(1171, 468);
            this.Controls.Add(this.btnListele);
            this.Controls.Add(this.btnKayıt);
            this.Controls.Add(this.btnİsBilgileri);
            this.Controls.Add(this.btnEğitimBilgileri);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmAkademisyenHrta";
            this.Text = "FrmAkademisyenHrta";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEğitimBilgileri;
        private System.Windows.Forms.Button btnİsBilgileri;
        private System.Windows.Forms.Button btnKayıt;
        private System.Windows.Forms.Button btnListele;
    }
}